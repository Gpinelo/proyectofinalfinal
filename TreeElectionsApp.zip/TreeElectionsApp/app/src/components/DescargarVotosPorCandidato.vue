<template>
  <v-row id="descargar-votos-partido" class="d-flex justify-center">
    <v-col md="9" sm="12">
      <v-card class="rounded-xl">
        <v-card-title>
          Descargar Votos -> Por Candidato
        </v-card-title>
        <v-divider></v-divider>
        <v-card-text>
          <v-form ref="form1" @submit.prevent>
            <v-row class="pa-4 d-flex align-center justify-start">
              <v-col cols="12" md="6">
                <v-select v-model="candidato" :items="listadoCandidatos" item-title="nombre" item-value="id"
                  :rules="[itemRequired]" label="Candidato" required></v-select>
              </v-col>
            </v-row>
            <v-row class="pa-4 d-flex flex-wrap align-center justify-center">
              <v-col cols="10" md="3">
                <v-btn v-if="formIsValid" @click.prevent="downloadVotesCsv" block elevated color="success">
                  Descargar (CSV)
                </v-btn>
                <v-btn v-else block elevated color="success" disabled>
                  Seleccione un candidato
                </v-btn>
              </v-col>
            </v-row>
          </v-form>
        </v-card-text>
      </v-card>
    </v-col>
  </v-row>

  <v-dialog v-model="stopped" width="auto" min-height="450" transition="dialog-top-transition">
    <v-card append-icon="$close" max-width="500" title="Error al enviar el formulario">
      <template v-slot:append>
        <v-btn icon="$close" variant="text" @click="stopped = false"></v-btn>
      </template>

      <v-divider></v-divider>

      <div class="mx-4 py-12 text-center">
        <v-icon class="mb-6" color="error" icon="mdi-alert-circle-outline" size="128"></v-icon>

        <div class="text-h4 font-weight-bold">No se pudo descargar el archivo, intente nuevamente.</div>
      </div>

      <v-divider></v-divider>

      <div class="pa-4 text-end">
        <v-btn class="text-none" color="red-accent-2" min-width="92" rounded variant="outlined" @click="stopped = false">
          Close
        </v-btn>
      </div>
    </v-card>

  </v-dialog>
</template>

<script>
import api from '../helpers/index'
import { mapStores } from 'pinia';
import { useLoadingStore } from '@/store/Loading';

export default {
  name: 'DescargarVotosPorCandidato',
  data: () => ({
    candidato: '',
    dialog: false,
    stopped: false,
    itemRequired: v => !!v || 'Este campo es obligatorio.',
    listadoCandidatos: [],
    data_votos: [],
    filename: 'Votos registrados por candidato.csv'
  }),
  computed: {
    ...mapStores(useLoadingStore),
    formIsValid() {
      return (this.candidato) ? true : false
    }
  },
  methods: {
    async getDataFromApi() {
      try {
        const candidatosDesordenados = await api.getCandidates()

        this.listadoCandidatos = candidatosDesordenados.map(candidato => {
          return {
            id: candidato._id,
            nombre: `${candidato.nombres} ${candidato.apellidos}`
          }
        })
      } catch (ex) {
        console.error(ex)
      }
    },
    async downloadVotesCsv() {

      this.loadingStore.toggleLoading()

      try {
        const listado_votos = await api.getCandidatesVotes(this.candidato)

        if (listado_votos.length > 0) {
          let csvContent = ""

          listado_votos.forEach(voto_row => {

            let row = Object.values(voto_row).join(',')

            csvContent += row + "\r\n"

          });

          const blob = new Blob([csvContent], { type: "data:text/csv;charset=utf-8," });

          if (navigator.msSaveBlob) {
            // IE 10+
            navigator.msSaveBlob(blob, this.filename);

          } else {

            const link = document.createElement("a");

            if (link.download !== undefined) { // feature detection

              // Browsers that support HTML5 download attribute
              const url = URL.createObjectURL(blob);
              link.setAttribute("href", url);
              link.setAttribute("download", this.filename);
              link.style.visibility = 'hidden';
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            }
          }
        } else {
          console.error("No existen datos para generar el archivo")
          this.stopped = true
        }

        this.loadingStore.toggleLoading()
      } catch (ex) {
        console.error("Ha ocurrido un error al generar el archivo", ex)
        this.stopped = true
        this.loadingStore.toggleLoading()
      }
    }
  },
  async created() {

    await this.getDataFromApi()
  }
}
</script>
