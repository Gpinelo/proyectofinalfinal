<template>
  <v-app-bar color="black" class="pr-5">
    <v-toolbar-title>
      App Elecciones
    </v-toolbar-title>
  </v-app-bar>
</template>
