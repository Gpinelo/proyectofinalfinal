import { Document } from 'mongoose'

export interface IPartido extends Document { 
  nombre: string
  descripcion: string
  logotipo: string
}