export interface ITreeVotes {
  candidato: string
  puesto: string,
  partido: string,
  departamento: string
  municipio: string,
  votos_totales: number
}

export interface ICandidateVotes {
  departamento: string,
  municipio: string,
  votos_totales: number
}

export interface IAssociationVotes {
  candidato: string,
  puesto: string,
  votos_totales: number
}