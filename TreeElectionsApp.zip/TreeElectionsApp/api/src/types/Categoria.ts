import { Document } from 'mongoose'

export interface ICategoria extends Document {
  nombre: string
  descripcion: string
  orden_categoria: number
}