import { Document } from 'mongoose'
import { IMunicipio } from './Municipio'
import { ICandidato } from './Candidato';

export interface IVoto extends Document {
  municipio: IMunicipio
  candidato: ICandidato
  no_mesa: number
  cant_votos: number
}