import { IMunicipio } from './Municipio'
import { ICandidato } from './Candidato';

export interface IBinome {
  municipio: IMunicipio
  candidatos: string[]
  no_mesa: number
  cant_votos: number
}