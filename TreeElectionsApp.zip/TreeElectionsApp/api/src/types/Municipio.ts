import { Document } from "mongoose"
import { IDepartamento } from './Departamento';

export interface IMunicipio extends Document {
  nombre: string
  departamento: IDepartamento
}