import { Document } from 'mongoose'
import { ICategoria } from './Categoria'
import { IPartido } from './Partido'

export interface ICandidato extends Document {
  nombres: string
  apellidos: string
  partido: IPartido
  categoria: ICategoria
}