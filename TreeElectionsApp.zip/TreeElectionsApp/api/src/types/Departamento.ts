import { Document } from 'mongoose'

export interface IDepartamento extends Document {
  nombre: string
}