import { IMunicipio } from '../types/Municipio'
import { model, Schema } from 'mongoose'

const municipiosSchema: Schema = new Schema(
  {
    nombre: String,
    departamento: {
      type: Schema.Types.ObjectId,
      ref: 'Departamentos'
    }
  },
  { timestamps: true }
)

export default model<IMunicipio>('Municipios', municipiosSchema)