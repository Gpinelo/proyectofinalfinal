import { IPartido } from '../types/Partido';
import { model, Schema } from 'mongoose'

const partidosSchema: Schema = new Schema(
  {
    nombre: String,
    descripcion: String,
    logotipo: String
  },
  { timestamps: true }
)

export default model<IPartido>('Partidos', partidosSchema)