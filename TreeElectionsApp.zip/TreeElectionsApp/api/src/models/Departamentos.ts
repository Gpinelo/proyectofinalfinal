import { IDepartamento } from '../types/Departamento'
import { model, Schema } from 'mongoose'

const departamentosSchema: Schema = new Schema(
  {
    nombre: String
  },
  { timestamps: true }
)

export default model<IDepartamento>('Departamentos', departamentosSchema)