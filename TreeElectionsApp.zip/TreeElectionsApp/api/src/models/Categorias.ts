import { ICategoria } from '../types/Categoria';
import { model, Schema } from 'mongoose'

const categoriasSchema: Schema = new Schema(
  {
    nombre: String,
    descripcion: String,
    orden_categoria: Number
  }
)

export default model<ICategoria>('Categorias', categoriasSchema)