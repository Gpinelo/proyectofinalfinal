import { IVoto } from '../types/Voto'
import { model, Schema } from 'mongoose'

const votosSchema: Schema = new Schema(
  {
    municipio: {
      type: Schema.Types.ObjectId,
      ref: 'Municipios'
    },
    candidato: {
      type: Schema.Types.ObjectId,
      ref: 'Candidatos'
    },
    no_mesa: Number,
    cant_votos: Number,
  },
  { timestamps: true }
)

export default model<IVoto>('Votos', votosSchema)