import { ICandidato } from '../types/Candidato'
import { model, Schema } from 'mongoose'

const candidatosSchema: Schema = new Schema(
  {
    nombres: String,
    apellidos: String,
    partido: {
      type: Schema.Types.ObjectId,
      ref: 'Partidos'
    },
    categoria: {
      type: Schema.Types.ObjectId,
      ref: 'Categorias'
    }
  },
  { timestamps: true }
)

export default model<ICandidato>('Candidates', candidatosSchema)