import { Router } from 'express'
import * as candidates from '../controllers/candidatos'
import * as categories from '../controllers/categorias'
import * as departments from '../controllers/departamentos'
import * as municipalities from '../controllers/municipios'
import * as associations from '../controllers/partidos'
import * as votes from '../controllers/votos'
import _default from '../controllers/default'

const router:Router = Router();

/* router.use((req, res, next) => {
  console.log('Time: ', Date.now());
  console.log("🚀 ~ file: index.ts:13 ~ router.use ~ req:", req)
  next()
}) */

router.get('/', _default)

router.get('/candidates/list', candidates.getCandidates)
router.post('/candidates/add', candidates.addCandidate)
router.put('/candidates/edit/:id', candidates.updateCandidate)
router.delete('/candidates/delete/:id', candidates.deleteCandidate)

router.get('/categories/list', categories.getCategories)
router.post('/categories/add', categories.addCategorie)
router.put('/categories/edit/:id', categories.updateCategorie)
router.delete('/categories/delete/:id', categories.deleteCategorie)

router.get('/departments/list', departments.getDepartments)
router.post('/departments/add', departments.addDepartment)
router.put('/departments/edit/:id', departments.updateDepartment)
router.delete('/departments/delete/:id', departments.deleteDepartment)

router.get('/municipalities/list', municipalities.getMunicipalities)
router.post('/municipalities/add', municipalities.addMunicipality)
router.put('/municipalities/edit/:id', municipalities.updateMunicipality)
router.delete('/municipalities/delete/:id', municipalities.deleteMunicipality)

router.get('/associations/list', associations.getAssociations)
router.post('/associations/add', associations.addAssociation)
router.put('/associations/edit/:id', associations.updateAssociation)
router.delete('/associations/delete/:id', associations.deleteAssociation)

router.get('/votes/list', votes.getVotes)
router.post('/votes/add', votes.addVote)
router.post('/votes/add/binome', votes.addBinomesVote)
router.put('/votes/edit/:id', votes.updateVote)
router.delete('/votes/delete/:id', votes.deleteVote)
router.get('/votes/file', votes.getFile)
router.get('/votes/file-for-candidate/:id', votes.getFileForCandidate)
router.get('/votes/file-for-association/:id', votes.getFileForAssociation)

export default router