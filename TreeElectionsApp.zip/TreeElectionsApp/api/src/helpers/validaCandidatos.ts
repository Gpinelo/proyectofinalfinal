import Candidatos from '../models/Candidatos'
import Categorias from '../models/Categorias'
import Partidos from '../models/Partidos'
import { ICandidato } from './../types/Candidato'
import { IPartido } from '../types/Partido';
import { ICategoria } from '../types/Categoria';
import { ICandidatosXPartidoXCategoria, ListadoCandidatos } from '../data/candidatos_default'

const validaCandidatos = async (): Promise<void> => {
  try {
    const candidatos: ICandidato[] = await Candidatos.find()

    if (candidatos.length > 0) {

      console.log("5️⃣ ~ validCoreDataExist ~ validaCandidatos ~ Existen candidatos en la base de datos")

    } else {

      console.log("📛 ~ validCoreDataExist ~ validaCandidatos ~ No existen candidatos creados")

      const partidos: IPartido[] = await Partidos.find()
      const categorias: ICategoria[] = await Categorias.find()

      if (partidos.length <= 0 || categorias.length <= 0) {

        throw "💀💀 ~ validCoreDataExist ~ validaCandidatos ~ No se pueden crear los candidatos"

      }

      console.log("⚡ ~ validCoreDataExist ~ validaCandidatos ~ Creando candidatos ...")

      let candidates: ICandidato[] = []

      for await (const candidato of ListadoCandidatos) {

        const partido = partidos.find(({ nombre }: IPartido) => nombre === candidato.partido)

        const categoria = categorias.find(({ orden_categoria }: ICategoria) => orden_categoria === candidato.categoria)

        const candidate: ICandidato = new Candidatos({
          nombres: candidato.nombres,
          apellidos: candidato.apellidos,
          partido: partido,
          categoria: categoria
        })
        
        const new_candidate = await candidate.save()

        candidates.push(new_candidate)
      }

      if (candidates.length > 0) {

        console.log("5️⃣ ~ validCoreDataExist ~ validaCandidatos ~ Existen candidatos en la base de datos")

      } else {

        throw "💀💀 ~ validCoreDataExist ~ validaCandidatos ~ ERROR: Los candidatos no fueron creados correctamente"
        
      }
    }
  } catch (error) {
    throw error
  }
}

export default validaCandidatos