import { IMunicipio } from './../types/Municipio'
import Municipios from '../models/Municipios'
import Departamentos from '../models/Departamentos'
import { ListadoMunicipios } from '../data/municipios_default'
import { IDepartamento } from '../types/Departamento';

const validaMunicipios = async (): Promise<void> => {
  try {
    const municipios: IMunicipio[] = await Municipios.find()

    if (municipios.length > 0) {

      console.log("2️⃣ ~ validCoreDataExist ~ validaMunicipios ~ Existen municipios en la base de datos")

    } else {
      
      console.log("📛 ~ validCoreDataExist ~ validaMunicipios ~ No existen municipios creados")

      const departamentos: IDepartamento[] = await Departamentos.find()

      if (departamentos.length <= 0) {
        
        throw "💀💀 ~ validCoreDataExist ~ validaMunicipios ~ No se pueden crear los municipios"

      }
      
      console.log("⚡ ~ validCoreDataExist ~ validaMunicipios ~ Creando municipios ...")

      let municipalities: IMunicipio[] = []

      for await (const { departamento, municipios } of ListadoMunicipios) {

        const department = departamentos.find(({ nombre }: IDepartamento) => nombre === departamento)

        for await (const municipio of municipios) {

          const municipality: IMunicipio = new Municipios({
            nombre: municipio,
            departamento: department
          })

          const new_municipality = await municipality.save()

          municipalities.push(new_municipality)

        }
      }

      if (municipalities.length > 0) {

        console.log("2️⃣ ~ validCoreDataExist ~ validaMunicipios ~ Existen municipios en la base de datos")

      } else {

        throw "💀💀 ~ validCoreDataExist ~ validaMunicipios ~ ERROR: Los municipios no fueron creados correctamente"
        
      }
    }
  } catch (error) {
    throw error
  }
}

export default validaMunicipios