import validaCandidatos from "./validaCandidatos"
import validaCategorias from "./validaCategorias"
import validaDepartamentos from "./validaDepartamentos"
import validaMunicipios from "./validaMunicipios"
import validaPartidos from "./validaPartidos"

export default async(): Promise<void> => {
  try {
    console.log("⚡ ~ validCoreDataExist ~ Validando datos esenciales para la aplicacion ...")

    await validaDepartamentos().then(async () => {
      await validaMunicipios()
    })
    
    await validaCategorias().then(async () => {
      await validaPartidos().then(async () => {
        await validaCandidatos()
      })
    })

    console.log("✅ ~ validCoreDataExist ~ Todos los datos necesarios existen en base de datos")

  } catch (error) {

    console.log("📛 ~ validCoreDataExist ~ Los datos necesarios no existen o no pudieron ser creados")

    throw error
  }
}
