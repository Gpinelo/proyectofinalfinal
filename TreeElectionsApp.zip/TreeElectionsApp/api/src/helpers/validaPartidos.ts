import { IPartido } from '../types/Partido'
import Partidos from '../models/Partidos'
import ListadoPartidos from '../data/partidos_default'

const validaPartidos = async(): Promise<void> => {
  try {
    const partidos: IPartido[] = await Partidos.find()

    if (partidos.length > 0) {

      console.log("4️⃣ ~ validCoreDataExist ~ validaPartidos ~ Existen partidos en la base de datos")
      
    } else {

      console.log("📛 ~ validCoreDataExist ~ validaPartidos ~ No existen partidos creados")

      console.log("⚡ ~ validCoreDataExist ~ validaPartidos ~ Creando partidos ...")

      let associations: IPartido[] = []

      for await (const partido of ListadoPartidos) {
        const association: IPartido = new Partidos({
          nombre: partido
        })

        const new_association = await association.save()

        associations.push(new_association)
      }
      
      if (associations.length > 0) {

        console.log("4️⃣ ~ validCoreDataExist ~ validaPartidos ~ Existen partidos en la base de datos")

      } else {

        throw "💀💀 ~ validCoreDataExist ~ validaPartidos ~ ERROR: Los partidos no fueron creados correctamente"
        
      }
    }
  } catch (error) {
    throw error
  }
}

export default validaPartidos