import { ICategoria } from '../types/Categoria'
import Categorias from '../models/Categorias'
import { ICategoriaDef, ListadoCategorias } from '../data/categorias_default'

const validaCategorias = async(): Promise<void> => {
  try {
    const categorias: ICategoria[] = await Categorias.find()

    if (categorias.length > 0) {

      console.log("3️⃣ ~ validCoreDataExist ~ validaCategorias ~ Existen categorias en la base de datos")
      
    } else {

      console.log("📛 ~ validCoreDataExist ~ validaCategorias ~ No existen categorias creados")

      console.log("⚡ ~ validCoreDataExist ~ validaCategorias ~ Creando categorias ...")

      let categories: ICategoria[] = []

      for await (const categoria of ListadoCategorias) {     
        const categorie: ICategoria = new Categorias({
          nombre: categoria.nombre,
          descripcion: categoria.descripcion,
          orden_categoria: categoria.orden_categoria
        })

        const new_categorie = await categorie.save()

        categories.push(new_categorie)
      }

      if (categories.length > 0) {

        console.log("3️⃣ ~ validCoreDataExist ~ validaCategorias ~ Existen categorias en la base de datos")

      } else {

        throw "💀💀 ~ validCoreDataExist ~ validaCategorias ~ ERROR: Las categorias no fueron creadas correctamente"
        
      }
    }
  } catch (error) {
    throw error
  }
}

export default validaCategorias