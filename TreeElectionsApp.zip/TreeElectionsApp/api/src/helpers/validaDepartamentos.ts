import { IDepartamento } from '../types/Departamento'
import Departamentos from '../models/Departamentos'
import ListadoDepartamentos from '../data/departamentos_default'

const validaDepartamentos = async (): Promise<void> => {
  try {
    const departamentos: IDepartamento[] = await Departamentos.find()

    if (departamentos.length > 0) {

      console.log("1️⃣ ~ validCoreDataExist ~ validaDepartamentos ~ Existen departamentos en la base de datos")

    } else {

      console.log("📛 ~ validCoreDataExist ~ validaDepartamentos ~ No existen departamentos creados")

      console.log("⚡ ~ validCoreDataExist ~ validaDepartamentos ~ Creando departamentos ...")

      let departments: IDepartamento[] = []

      for await (const departamento of ListadoDepartamentos) {
        const department: IDepartamento = new Departamentos({
          nombre: departamento
        })

        const new_department = await department.save()

        departments.push(new_department)
      }

      if (departments.length > 0) {

        console.log("1️⃣ ~ validCoreDataExist ~ validaDepartamentos ~ Existen departamentos en la base de datos")

      } else {

        throw "💀💀 ~ validCoreDataExist ~ validaDepartamentos ~ ERROR: Los departamentos no fueron creados correctamente"
        
      }
    }
  } catch (error) {
    throw error
  }
}

export default validaDepartamentos