import express, { Express } from 'express'
import mongoose from 'mongoose'
import cors from 'cors'
import routes from './routes/index'
import validCoreDataExist from './helpers/validCoreDataExist'

const app: Express = express()

const PORT: string | number = 10016
const USER: string | undefined = process.env.MONGO_USER
const PASSWORD: string | undefined = process.env.MONGO_PASSWORD
const DB: string | undefined = process.env.MONGO_DB
const HOST: string | undefined = process.env.MONGO_HOST

app.use(cors())
app.use(express.json())
app.use(routes)


const uri = `mongodb://${USER}:${PASSWORD}@${HOST}/${DB}?authSource=admin`


mongoose.set('strictQuery', true)
mongoose
  .connect(uri)
  .then(async () => {
    console.log(`🚀 ~ Connected to: ${DB} ~ On: ${HOST}`)

    try {
      await validCoreDataExist()

      app.listen(PORT, () => console.log(`🚀 ~ Server running on: http://localhost:${PORT}`))
    } catch (error)
    {
      throw error
    }
  })
  .catch(error => {
    console.log('💀💀 An error ocurred 💀💀')
    throw error
  })
