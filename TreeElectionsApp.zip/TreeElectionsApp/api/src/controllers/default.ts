import { Request, Response } from 'express'


export default async(_req: Request, res: Response):Promise<void> => {
  res.status(200).json('Api running');
}