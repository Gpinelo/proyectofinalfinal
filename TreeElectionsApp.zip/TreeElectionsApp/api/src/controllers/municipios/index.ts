import Departamentos from '../../models/Departamentos'
import Municipios from '../../models/Municipios'
import { IMunicipio } from './../../types/Municipio'
import { Request, Response } from 'express'

const getMunicipalities = async(_req: Request, res: Response):Promise<void> => {
  try {
    const municipalities: IMunicipio[] = await Municipios.find();

    res.status(200).json({ municipalities });
  } catch (error) {
    throw error
  }
}

const addMunicipality = async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body as Pick<IMunicipio, "nombre" | "departamento">

    const department = await Departamentos.findById(body.departamento)

    const municipality: IMunicipio = new Municipios({
      nombre: body.nombre,
      departamento: department
    })

    const new_municipality: IMunicipio = await municipality.save()

    res
      .status(201)
      .json({
        message: "Municipality Added",
        new_municipality
      })

  } catch (error) {
    throw error
  }
}

const updateMunicipality = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      params: { id },
      body,
    } = req

    const updated_municipality: IMunicipio | null = await Municipios.findByIdAndUpdate(
      { _id: id },
      body
    )

    res
      .status(200)
      .json({
        message: "Municipality updated",
        updated_municipality
      })
      
  } catch (error) {
    throw error
  }
}

const deleteMunicipality = async (req: Request, res: Response): Promise<void> => {
  try {
    const { params: { id } } = req

    const deleted_municipality: IMunicipio | null = await Municipios.findByIdAndRemove(id)

    res
      .status(200)
      .json({
        message: "Municipality deleted",
        deleted_municipality
      })
  } catch (error) {
    throw error
  }
}

export { getMunicipalities, addMunicipality, updateMunicipality, deleteMunicipality }