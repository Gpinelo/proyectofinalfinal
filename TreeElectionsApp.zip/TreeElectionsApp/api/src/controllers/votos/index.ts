import Municipios from '../../models/Municipios'
import Candidatos from '../../models/Candidatos'
import Votos from '../../models/Votos'
import Departamentos from '../../models/Departamentos'
import Partidos from '../../models/Partidos'
import { IVoto } from '../../types/Voto'
import { IBinome } from '../../types/Binome'
import { IMunicipio } from '../../types/Municipio'
import { IDepartamento } from '../../types/Departamento'
import { ICandidato } from '../../types/Candidato'
import { Request, Response } from 'express'
import { ICategoria } from '../../types/Categoria'
import Categorias from '../../models/Categorias'
import { IPartido } from '../../types/Partido'
import { ITreeVotes, ICandidateVotes, IAssociationVotes } from '../../types/TreeVotes';

const getVotes = async (_req: Request, res: Response): Promise<void> => {
  try {
    const votes: IVoto[] = await Votos.find();

    res.status(200).json({ votes });
  } catch (error) {
    throw error
  }
}

const getFileForAssociation = async (req: Request, res: Response): Promise<void> => {
  try {
    const { params: { id } } = req

    const association: IPartido | null = await Partidos.findById(id)

    if (association !== null) {
      const candidates: ICandidato[] = await Candidatos.find()
      const categories: ICategoria[] = await Categorias.find()

      const departments: IDepartamento[] = await Departamentos.find()
      const municipalities: IMunicipio[] = await Municipios.find()
  
      const votes: IVoto[] = await Votos.find()
  
      const ordered_votes: IAssociationVotes[] = []

      const candidatos_x_partido: ICandidato[] = candidates.filter(({ partido }) => partido?.toString() === association?._id?.toString())

      for await (const candidate of candidatos_x_partido) {
        const puesto: ICategoria | undefined = categories.find(({ _id }) => _id?.toString() === candidate?.categoria?.toString())

        const votos_x_departamento: number[] = []  
        for await (const department of departments) {
          const municipios_x_departamento: IMunicipio[] = municipalities.filter(({ departamento }) => departamento?.toString() === department?._id?.toString())
    
          const votos_x_municipio: number[] = []
          for await (const municipality of municipios_x_departamento) {
            const votos_filtrados: IVoto[] = votes.filter(({ candidato, municipio }) => candidato?.toString() === candidate?._id.toString() && municipio.toString() === municipality?._id?.toString())
    
            const votos_ordenados: number[] = votos_filtrados.map(voto => voto.cant_votos)
    
            const votos_totales: number = votos_ordenados.reduce((ac, cu) => ac + cu, 0);

            votos_x_municipio.push(votos_totales)
          }
          
          const votos_mun_totales: number = votos_x_municipio.reduce((ac, cu) => ac + cu, 0)
          votos_x_departamento.push(votos_mun_totales)
        }

        const votos_candidato: number = votos_x_departamento.reduce((ac, cu) => ac + cu, 0)


        const row_vote: IAssociationVotes = {
          candidato: candidate?.nombres + ' ' + candidate?.apellidos,
          puesto: puesto?.nombre || '',
          votos_totales: votos_candidato
        }

        ordered_votes.push(row_vote)
      }

      res.status(200).json(ordered_votes)
    } else {
      const error: string = 'La petición es incorrecta o el partido no existe.'
      res.status(400).send(error)
    }
  } catch (ex) {
    console.log("🚀 ~ file: index.ts:86 ~ getFileForAssociation ~ ex:", ex)
    res.status(400).send(ex)
    throw ex
  }
}

const getFileForCandidate = async (req: Request, res: Response): Promise<void> => {
  try {
    const { params: { id } } = req

    const candidate: ICandidato | null = await Candidatos.findById(id)

    if (candidate !== null) {
      const departments: IDepartamento[] = await Departamentos.find()
      const municipalities: IMunicipio[] = await Municipios.find()
  
      const votes: IVoto[] = await Votos.find()
  
      const ordered_votes: ICandidateVotes[] = []
  
      for await (const department of departments) {
        const municipios_x_departamento: IMunicipio[] = municipalities.filter(({ departamento }) => departamento?.toString() === department?._id?.toString())
  
        for await (const municipality of municipios_x_departamento) {
          const votos_filtrados: IVoto[] = votes.filter(({ candidato, municipio }) => candidato?.toString() === candidate?._id.toString() && municipio.toString() === municipality?._id?.toString())
  
          const votos_ordenados: number[] = votos_filtrados.map(voto => voto.cant_votos)
  
          const votos_totales: number = votos_ordenados.reduce((ac, cu) => ac + cu, 0);
  
          const row_vote: ICandidateVotes = {
            departamento: department?.nombre,
            municipio: municipality?.nombre,
            votos_totales
          }
  
          ordered_votes.push(row_vote)
        }
      }

      res.status(200).json(ordered_votes)
    } else {
      const error: string = 'La petición es incorrecta o el candidato no existe.'
      res.status(400).send(error)
    }
  } catch (ex) {
    console.log("🚀 ~ file: index.ts:66 ~ getFileForCandidate ~ ex:", ex)
    res.status(400).send(ex)
    throw ex
  }
}

const getFile = async (_req: Request, res: Response): Promise<void> => {
  try {
    const candidates: ICandidato[] = await Candidatos.find()

    const categories: ICategoria[] = await Categorias.find()
    const associations: IPartido[] = await Partidos.find()

    const departments: IDepartamento[] = await Departamentos.find()
    const municipalities: IMunicipio[] = await Municipios.find()

    const votes: IVoto[] = await Votos.find()

    const ordered_votes: ITreeVotes[] = []

    for await (const candidate of candidates) {
      const puesto: ICategoria | undefined = categories.find(({ _id }) => _id?.toString() === candidate?.categoria?.toString())
      const partido: IPartido | undefined = associations.find(({ _id }) => _id?.toString() === candidate?.partido?.toString())

      for await (const department of departments) {
        const municipios_x_departamento: IMunicipio[] = municipalities.filter(({ departamento }) => departamento?.toString() === department?._id?.toString())

        for await (const municipality of municipios_x_departamento) {
          const votos_filtrados: IVoto[] = votes.filter(({ candidato, municipio }) => candidato?.toString() === candidate?._id?.toString() && municipio.toString() === municipality?._id?.toString())

          const votos_ordenados: number[] = votos_filtrados.map(voto => voto.cant_votos)

          const votos_totales: number = votos_ordenados.reduce((ac, cu) => ac + cu, 0);

          const row_vote: ITreeVotes = {
            candidato: candidate?.nombres + ' ' + candidate?.apellidos,
            puesto: puesto?.nombre || '',
            partido: partido?.nombre || '',
            departamento: department?.nombre,
            municipio: municipality?.nombre,
            votos_totales
          }

          ordered_votes.push(row_vote)
        }
      }
    }

    res.status(200).json(ordered_votes);
  } catch (error) {
    console.log("🚀 ~ file: index.ts:72 ~ getFile ~ error:", error)
    res.status(400).send(error)
    throw error
  }
}

const addBinomesVote = async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body as Pick<IBinome, "municipio" | "candidatos" | "no_mesa" | "cant_votos">

    const municipality = await Municipios.findById(body.municipio)

    const candidate_1 = await Candidatos.findById(body.candidatos[0])
    const candidate_2 = await Candidatos.findById(body.candidatos[0])

    const vote_1: IVoto = new Votos({
      municipio: municipality,
      candidato: candidate_1,
      no_mesa: body.no_mesa,
      cant_votos: body.cant_votos
    })
    const vote_2: IVoto = new Votos({
      municipio: municipality,
      candidato: candidate_2,
      no_mesa: body.no_mesa,
      cant_votos: body.cant_votos
    })

    const new_vote_1: IVoto = await vote_1.save()
    const new_vote_2: IVoto = await vote_2.save()

    res
      .status(201)
      .json({
        message: "Vote Added",
        votes: {
          new_vote_1,
          new_vote_2
        }
      })

  } catch (ex) {
    throw ex
  }
}

const addVote = async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body as Pick<IVoto, "municipio" | "candidato" | "no_mesa" | "cant_votos">

    const municipality = await Municipios.findById(body.municipio)
    const candidate = await Candidatos.findById(body.candidato)

    const vote: IVoto = new Votos({
      municipio: municipality,
      candidato: candidate,
      no_mesa: body.no_mesa,
      cant_votos: body.cant_votos
    })

    const new_vote: IVoto = await vote.save()

    res
      .status(201)
      .json({
        message: "Vote Added",
        new_vote
      })

  } catch (error) {
    throw error
  }
}

const updateVote = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      params: { id },
      body,
    } = req

    const updated_vote: IVoto | null = await Votos.findByIdAndUpdate(
      { _id: id },
      body
    )

    res
      .status(200)
      .json({
        message: "Vote updated",
        updated_vote
      })

  } catch (error) {
    throw error
  }
}

const deleteVote = async (req: Request, res: Response): Promise<void> => {
  try {
    const { params: { id } } = req

    const deleted_vote: IVoto | null = await Votos.findByIdAndRemove(id)

    res
      .status(200)
      .json({
        message: "Vote deleted",
        deleted_vote
      })
  } catch (error) {
    throw error
  }
}

export { getVotes, addBinomesVote, addVote, updateVote, deleteVote, getFile, getFileForCandidate, getFileForAssociation }