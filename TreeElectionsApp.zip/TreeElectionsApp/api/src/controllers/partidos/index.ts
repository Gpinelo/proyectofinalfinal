import Partidos from '../../models/Partidos'
import { IPartido } from './../../types/Partido';
import { Request, Response } from 'express'

const getAssociations = async(_req: Request, res: Response):Promise<void> => {
  try {
    const partidos: IPartido[] = await Partidos.find();

    res.status(200).json({ partidos });
  } catch (error) {
    throw error
  }
}

const addAssociation = async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body as Pick<IPartido, "nombre" | "descripcion" | "logotipo">

    const association: IPartido = new Partidos({
      nombre: body.nombre,
      descripcion: body.descripcion,
      logotipo: body.logotipo,
    })

    const new_association: IPartido = await association.save()

    res
      .status(201)
      .json({
        message: "Association Added",
        new_association
      })

  } catch (error) {
    throw error
  }
}

const updateAssociation = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      params: { id },
      body,
    } = req

    const updated_association: IPartido | null = await Partidos.findByIdAndUpdate(
      { _id: id },
      body
    )

    res
      .status(200)
      .json({
        message: "Association updated",
        updated_association
      })
      
  } catch (error) {
    throw error
  }
}

const deleteAssociation = async (req: Request, res: Response): Promise<void> => {
  try {
    const { params: { id } } = req

    const deleted_association: IPartido | null = await Partidos.findByIdAndRemove(id)

    res
      .status(200)
      .json({
        message: "Association deleted",
        deleted_association
      })
  } catch (error) {
    throw error
  }
}

export { getAssociations, addAssociation, updateAssociation, deleteAssociation }