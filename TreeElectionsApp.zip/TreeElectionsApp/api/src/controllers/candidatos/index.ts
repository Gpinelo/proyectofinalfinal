import Candidatos from '../../models/Candidatos'
import Partidos from '../../models/Partidos'
import Categorias from '../../models/Categorias'
import { ICandidato } from './../../types/Candidato'
import { Request, Response } from 'express'

const getCandidates = async(_req: Request, res: Response):Promise<void> => {
  try {
    const candidatos: ICandidato[] = await Candidatos.find();

    res.status(200).json({ candidatos });
  } catch (error) {
    throw error
  }
}

const addCandidate = async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body as Pick<ICandidato, "nombres" | "apellidos" | 'partido' | 'categoria'>

    const association = await Partidos.findById(body.partido)
    const categorie = await Categorias.findById(body.categoria)

    const candidate: ICandidato = new Candidatos({
      nombres: body.nombres,
      apellidos: body.apellidos,
      partido: association,
      categoria: categorie
    })

    const new_candidate: ICandidato = await candidate.save()

    res
      .status(201)
      .json({
        message: "Candidate Added",
        new_candidate
      })

  } catch (error) {
    throw error
  }
}

const updateCandidate = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      params: { id },
      body,
    } = req

    const updated_candidate: ICandidato | null = await Candidatos.findByIdAndUpdate(
      { _id: id },
      body
    )

    res
      .status(200)
      .json({
        message: "Candidate updated",
        updated_candidate
      })
      
  } catch (error) {
    throw error
  }
}

const deleteCandidate = async (req: Request, res: Response): Promise<void> => {
  try {
    const { params: { id } } = req

    const deleted_candidate: ICandidato | null = await Candidatos.findByIdAndRemove(id)

    res
      .status(200)
      .json({
        message: "Candidate deleted",
        deleted_candidate
      })
  } catch (error) {
    throw error
  }
}

export { getCandidates, addCandidate, updateCandidate, deleteCandidate }