import { IDepartamento } from './../../types/Departamento'
import Departamentos from '../../models/Departamentos'
import { Request, Response } from 'express'

const getDepartments = async(_req: Request, res: Response):Promise<void> => {
  try {
    const departamento: IDepartamento[] = await Departamentos.find();

    res.status(200).json({ departamento });
  } catch (error) {
    throw error
  }
}

const addDepartment = async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body as Pick<IDepartamento, "nombre" >

    const department: IDepartamento = new Departamentos({
      nombre: body.nombre
    })

    const new_department: IDepartamento = await department.save()

    res
      .status(201)
      .json({
        message: "Department Added",
        new_department
      })

  } catch (error) {
    throw error
  }
}

const updateDepartment = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      params: { id },
      body,
    } = req

    const updated_department: IDepartamento | null = await Departamentos.findByIdAndUpdate(
      { _id: id },
      body
    )

    res
      .status(200)
      .json({
        message: "Department updated",
        updated_department
      })
      
  } catch (error) {
    throw error
  }
}

const deleteDepartment = async (req: Request, res: Response): Promise<void> => {
  try {
    const { params: { id } } = req

    const deleted_department: IDepartamento | null = await Departamentos.findByIdAndRemove(id)

    res
      .status(200)
      .json({
        message: "Department deleted",
        deleted_department
      })
  } catch (error) {
    throw error
  }
}

export { getDepartments, addDepartment, updateDepartment, deleteDepartment }