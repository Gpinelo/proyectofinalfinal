import { ICategoria } from './../../types/Categoria'
import Categorias from '../../models/Categorias'
import { Request, Response } from 'express'

const getCategories = async(_req: Request, res: Response):Promise<void> => {
  try {
    const categorias: ICategoria[] = await Categorias.find();

    res.status(200).json({ categorias });
  } catch (error) {
    throw error
  }
}

const addCategorie = async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body as Pick<ICategoria, "nombre" | "descripcion" | "orden_categoria">

    const categoria: ICategoria = new Categorias({
      nombre: body.nombre,
      descripcion: body.descripcion,
      orden_categoria: body.orden_categoria,
    })

    const nueva_categoria: ICategoria = await categoria.save()

    res
      .status(201)
      .json({
        message: "Categorie Added",
        nueva_categoria
      })

  } catch (error) {
    throw error
  }
}

const updateCategorie = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      params: { id },
      body,
    } = req

    const updated_categorie: ICategoria | null = await Categorias.findByIdAndUpdate(
      { _id: id },
      body
    )

    res
      .status(200)
      .json({
        message: "Categorie updated",
        updated_categorie
      })
      
  } catch (error) {
    throw error
  }
}

const deleteCategorie = async (req: Request, res: Response): Promise<void> => {
  try {
    const { params: { id } } = req

    const deleted_categorie: ICategoria | null = await Categorias.findByIdAndRemove(id)

    res
      .status(200)
      .json({
        message: "Categorie deleted",
        deleted_categorie
      })
  } catch (error) {
    throw error
  }
}

export { getCategories, addCategorie, updateCategorie, deleteCategorie }