export interface ICandidatosXPartidoXCategoria {
  nombres: string
  apellidos: string
  partido: string
  categoria: number
}

export const ListadoCandidatos: ICandidatosXPartidoXCategoria[] = [
  {
    nombres: 'Ricardo',
    apellidos: 'Sagastume',
    partido: 'Todos',
    categoria: 1
  },
  {
    nombres: 'Guillermo',
    apellidos: 'González',
    partido: 'Todos',
    categoria: 2
  },
  {
    nombres: 'Isaac',
    apellidos: 'Farchi',
    partido: 'Azul',
    categoria: 1
  },
  {
    nombres: 'Mauricio',
    apellidos: 'Zaldaña',
    partido: 'Azul',
    categoria: 2
  },
  {
    nombres: 'Rafael',
    apellidos: 'Espada',
    partido: 'Partido Republicano',
    categoria: 1
  },
  {
    nombres: 'Arturo',
    apellidos: 'Herrador',
    partido: 'Partido Republicano',
    categoria: 2
  },
  {
    nombres: 'Zury',
    apellidos: 'Ríos',
    partido: 'Coalición Valor-Unionista',
    categoria: 1
  },
  {
    nombres: 'Héctor',
    apellidos: 'Cifuentes',
    partido: 'Coalición Valor-Unionista',
    categoria: 2
  },
  {
    nombres: 'Luis',
    apellidos: 'Lam',
    partido: 'PIN',
    categoria: 1
  },
  {
    nombres: 'Otto',
    apellidos: 'Marroquín',
    partido: 'PIN',
    categoria: 2
  },
  {
    nombres: 'Rudio Lecsan',
    apellidos: 'Mérida Herrera',
    partido: 'Humanista',
    categoria: 1
  },
  {
    nombres: 'Rubén Darío',
    apellidos: 'Morales',
    partido: 'Humanista',
    categoria: 2
  },
  {
    nombres: 'Edmond',
    apellidos: 'Mulet',
    partido: 'Cabal',
    categoria: 1
  },
  {
    nombres: 'Max',
    apellidos: 'Santa Cruz',
    partido: 'Cabal',
    categoria: 2
  },
  {
    nombres: 'Manuel',
    apellidos: 'Conde',
    partido: 'Vamos',
    categoria: 1
  },
  {
    nombres: 'Luis',
    apellidos: 'Suárez',
    partido: 'Vamos',
    categoria: 2
  },
  {
    nombres: 'Sandra',
    apellidos: 'Torres',
    partido: 'Une',
    categoria: 1
  },
  {
    nombres: 'Romeo Estuardo',
    apellidos: 'Guerra Lemus',
    partido: 'Une',
    categoria: 2
  },
  {
    nombres: 'Carlos',
    apellidos: 'Pineda',
    partido: 'Prosperidad Ciudadana',
    categoria: 1
  },
  {
    nombres: 'Efraín',
    apellidos: 'Orozco',
    partido: 'Prosperidad Ciudadana',
    categoria: 2
  },
  {
    nombres: 'Rudy',
    apellidos: 'Guzmán',
    partido: 'Nosotros',
    categoria: 1
  },
  {
    nombres: 'Diego',
    apellidos: 'González',
    partido: 'Nosotros',
    categoria: 2
  },
  {
    nombres: 'Amílcar',
    apellidos: 'Rivera',
    partido: 'Victoria',
    categoria: 1
  },
  {
    nombres: 'Fernando',
    apellidos: 'Mazariegos',
    partido: 'Victoria',
    categoria: 2
  },
  {
    nombres: 'Giulio',
    apellidos: 'Talamonti',
    partido: 'Unión Republicana',
    categoria: 1
  },
  {
    nombres: 'Oscar',
    apellidos: 'Barrientos',
    partido: 'Unión Republicana',
    categoria: 2
  },
  {
    nombres: 'César Bernardo',
    apellidos: 'Arévalo',
    partido: 'Movimiento Semilla',
    categoria: 1
  },
  {
    nombres: 'Karin',
    apellidos: 'Herrera',
    partido: 'Movimiento Semilla',
    categoria: 2
  },
  {
    nombres: 'Hugo',
    apellidos: 'Peña',
    partido: 'Comunidad Elefante',
    categoria: 1
  },
  {
    nombres: 'Hugo',
    apellidos: 'Jhonson',
    partido: 'Comunidad Elefante',
    categoria: 2
  },
  {
    nombres: 'Samuel',
    apellidos: 'Morales',
    partido: 'FCN-Nación',
    categoria: 1
  },
  {
    nombres: 'Miguel Ángel',
    apellidos: 'Moir',
    partido: 'FCN-Nación',
    categoria: 2
  },
  {
    nombres: 'Amílcar',
    apellidos: 'Pop',
    partido: 'Coalición Winaq-URNG',
    categoria: 1
  },
  {
    nombres: 'Mónica',
    apellidos: 'Enríquez',
    partido: 'Coalición Winaq-URNG',
    categoria: 2
  },
  {
    nombres: 'Armando',
    apellidos: 'Castillo',
    partido: 'Viva',
    categoria: 1
  },
  {
    nombres: 'Édgar',
    apellidos: 'Grisolia',
    partido: 'Viva',
    categoria: 2
  },
  {
    nombres: 'Giovanni',
    apellidos: 'Reyes',
    partido: 'Bien',
    categoria: 1
  },
  {
    nombres: 'Oscar',
    apellidos: 'Figueroa',
    partido: 'Bien',
    categoria: 2
  },
  {
    nombres: 'Álvaro',
    apellidos: 'Trujillo',
    partido: 'Cambio',
    categoria: 1
  },
  {
    nombres: 'Miguel Angel',
    apellidos: 'Ibarra',
    partido: 'Cambio',
    categoria: 2
  },
  {
    nombres: 'Manuel Ricardo',
    apellidos: 'Villacorta Orantes',
    partido: 'Vos',
    categoria: 1
  },
  {
    nombres: 'Jorge Mario',
    apellidos: 'García España',
    partido: 'Vos',
    categoria: 2
  },
  {
    nombres: 'Francisco',
    apellidos: 'Arredondo',
    partido: 'CREO',
    categoria: 1
  },
  {
    nombres: 'Francisco Bermúdez',
    apellidos: 'Amado',
    partido: 'CREO',
    categoria: 2
  },
  {
    nombres: 'Julio',
    apellidos: 'Rivera Clavería',
    partido: 'Partido Mi Familia',
    categoria: 1
  },
  {
    nombres: 'José Enrique',
    apellidos: 'Urrutia Estrada',
    partido: 'Partido Mi Familia',
    categoria: 2
  },
  {
    nombres: 'Oscar Rodolfo',
    apellidos: 'Castañeda',
    partido: 'Partido Poder',
    categoria: 1
  },
  {
    nombres: 'Luis Adrián',
    apellidos: 'Ruiz',
    partido: 'Partido Poder',
    categoria: 2
  },
]