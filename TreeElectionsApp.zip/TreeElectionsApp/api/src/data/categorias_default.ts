export interface ICategoriaDef {
  nombre: string
  descripcion: string
  orden_categoria: number
}

export const ListadoCategorias: ICategoriaDef[] = [
  {
    nombre: 'Binomio Presidencial',
    descripcion: 'Candidatos a presidente y vicepresidente de Guatemala',
    orden_categoria: 0
  },
  {
    nombre: 'Presidente',
    descripcion: 'Candidatos a presidente Guatemala',
    orden_categoria: 1
  },
  {
    nombre: 'Vicepresidente',
    descripcion: 'Candidatos a vicepresidente de Guatemala',
    orden_categoria: 2
  },
]